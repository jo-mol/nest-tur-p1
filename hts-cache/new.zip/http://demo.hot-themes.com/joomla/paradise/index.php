<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" >
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<!--[if lt IE 9]>
	<script src="/joomla/paradise/templates/sparky_framework/js/html5shiv.min.js"></script>
	<script src="/joomla/paradise/templates/sparky_framework/js/respond.min.js"></script>
<![endif]-->

<link href="/joomla/paradise/templates/sparky_framework/images/icons/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
<link href="/joomla/paradise/templates/sparky_framework/images/icons/icon180x180.png" rel="apple-touch-icon" />
<link href="/joomla/paradise/templates/sparky_framework/images/icons/icon192x192.png" rel="icon" sizes="192x192" />

<base href="http://demo.hot-themes.com/joomla/paradise/index.php" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="generator" content="Joomla! - Open Source Content Management" />
	<title>Hot Paradise</title>
	<link href="/joomla/paradise/index.php?format=feed&amp;type=rss" rel="alternate" type="application/rss+xml" title="RSS 2.0" />
	<link href="/joomla/paradise/index.php?format=feed&amp;type=atom" rel="alternate" type="application/atom+xml" title="Atom 1.0" />
	<link href="http://demo.hot-themes.com/joomla/paradise/index.php/component/search/?Itemid=195&amp;format=opensearch" rel="search" title="Search Hot Paradise" type="application/opensearchdescription+xml" />
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,regular,500,700,900&amp;subset=latin" rel="stylesheet" type="text/css" />
	<link href="/joomla/paradise/templates/sparky_framework/css/normalize.css" rel="stylesheet" type="text/css" />
	<link href="/joomla/paradise/media/jui/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="/joomla/paradise/templates/sparky_framework/css/sparky-id83-180526075302.css" rel="stylesheet" type="text/css" />
	<link href="/joomla/paradise/modules/mod_hot_counters/css/style.css" rel="stylesheet" type="text/css" />
	<link href="/joomla/paradise/modules/mod_hot_swipe_carousel/tmpl/style.css" rel="stylesheet" type="text/css" />
	<style type="text/css">


.counter_field {
  width: 25%;
  float:left;
  text-align: center;
  margin: 30px 0;
}

.counter_number {
  font-size: 36px;
  margin: 40px 0 20px;
  color:#ffffff;
}

.counter_text {
  font-size: 18px;
  color:#ffffff;
}

@media (max-width: 768px) {

  .counter_field {
    width: 100%;
    float:none;
  }

}



.hot_swipe_carousel_slides .contents {
    top: 20%;
    left: 35%;
    width: 50%;
    color: #ffffff;
    padding: 0%;
    background: rgba(0,0,0,0);
    font-size:18px;
    opacity:0;
}

.hot_swipe_carousel_slides .contents h2 {
    font-size:20px;
}

.hot_swipe_carousel_slides img {
    max-width: 99999px;
    width: 100%;
}

.hot_swipe_carousel_slides .contents {
    position: absolute;
}



.hot_swipe_carousel_slides .gallery-cell {
    width: 100%;
}


	</style>
	<script src="/joomla/paradise/media/jui/js/jquery.min.js?8ba14361d8bc7355c05fc192c4c37f9d" type="text/javascript"></script>
	<script src="/joomla/paradise/media/jui/js/jquery-noconflict.js?8ba14361d8bc7355c05fc192c4c37f9d" type="text/javascript"></script>
	<script src="/joomla/paradise/media/jui/js/jquery-migrate.min.js?8ba14361d8bc7355c05fc192c4c37f9d" type="text/javascript"></script>
	<script src="/joomla/paradise/media/system/js/caption.js?8ba14361d8bc7355c05fc192c4c37f9d" type="text/javascript"></script>
	<script src="/joomla/paradise/media/jui/js/bootstrap.min.js?8ba14361d8bc7355c05fc192c4c37f9d" type="text/javascript"></script>
	<script src="/joomla/paradise/templates/sparky_framework/js/sparky-id83-180526075302.js" type="text/javascript"></script>
	<script src="http://demo.hot-themes.com/joomla/paradise/modules/mod_hot_counters/js/jquery.appear.js" type="text/javascript"></script>
	<script src="http://demo.hot-themes.com/joomla/paradise/modules/mod_hot_counters/js/jquery.animateNumber.min.js" type="text/javascript"></script>
	<script src="http://demo.hot-themes.com/joomla/paradise/modules/mod_hot_swipe_carousel/js/flickity.pkgd.min.js" type="text/javascript"></script>
	<!--[if lt IE 9]><script src="/joomla/paradise/media/system/js/html5fallback.js?8ba14361d8bc7355c05fc192c4c37f9d" type="text/javascript"></script><![endif]-->
	<script type="text/javascript">
jQuery(window).on('load',  function() {
				new JCaption('img.caption');
			});
	</script>


<script type="text/javascript" src="/joomla/paradise/templates/sparky_framework/js/responsive-nav.min.js"></script></head>
<body class="sparky_home home">
<div id="blocker"></div><div class="sparky_wrapper">
    <div  class="sparky_row1 sparky_full logorow one">
        <div class="sparky_container">
        <div class="sparky_cell mp_logo sparkle3">
	<div class="sparky_feature">
		<a href="/joomla/paradise" class="sparky_logo_link">
					    <div class="sparky_logo"><span>PA</span><span>RA</span><span>DI</span><span>SE</span></div>
		    <div class="sparky_slogan"></div>
		    	    </a>
	</div>
</div><div class="sparky_cell mp_topmenu sparkle7">
	<div class="sparky_menu">
	
<nav class="container_topmenu">

	
	<ul class="menu navv mnu_topmenu">
<li class="item-195 current active"><a href="/joomla/paradise/index.php" >Home</a></li><li class="item-346"><a href="/joomla/paradise/index.php/about-us" >About Us</a></li><li class="item-512"><a href="/joomla/paradise/index.php/gallery" >Gallery</a></li><li class="item-344 deeper parent"><a href="#" >Features</a><ul><li class="item-352 deeper parent"><a href="#" >Extensions</a><ul><li class="item-353"><a href="/joomla/paradise/index.php/features/extensions/hot-swipe-carousel" >Hot Swipe Carousel</a></li><li class="item-426"><a href="/joomla/paradise/index.php/features/extensions/hot-responsive-lightbox" >Hot Responsive Lightbox</a></li><li class="item-354"><a href="/joomla/paradise/index.php/features/extensions/hot-slicebox" >Hot Slicebox</a></li><li class="item-355"><a href="/joomla/paradise/index.php/features/extensions/hot-maps" >Hot Maps</a></li><li class="item-534"><a href="/joomla/paradise/index.php/features/extensions/hot-counters" >Hot Counters</a></li></ul></li><li class="item-348"><a href="/joomla/paradise/index.php/features/infinite-color-schemes" >Color Schemes</a></li><li class="item-221 deeper parent"><a href="#" >Color Variants</a><ul><li class="item-142"><a href="http://demo.hot-themes.com/joomla/paradise/index.php?style=1" >Color Variant 1 (Red)</a></li><li class="item-143"><a href="http://demo.hot-themes.com/joomla/paradise/index.php?style=2" >Color Variant 2 (Green)</a></li><li class="item-144"><a href="http://demo.hot-themes.com/joomla/paradise/index.php?style=3" >Color Variant 3 (Blue)</a></li><li class="item-567"><a href="http://demo.hot-themes.com/joomla/paradise/index.php?style=4" >Color Variant 4 (Orange)</a></li></ul></li><li class="item-347"><a href="/joomla/paradise/index.php/features/drop-down-menu" >Drop-down Menu</a></li><li class="item-148"><a href="/joomla/paradise/index.php/features/installation-and-usage" >Installation and Usage</a></li><li class="item-349"><a href="/joomla/paradise/index.php/features/module-positions" >Module Positions</a></li><li class="item-350"><a href="/joomla/paradise/index.php/features/no-conflicts" >No Conflicts</a></li><li class="item-351"><a href="/joomla/paradise/index.php/features/seo-friendly" >SEO Friendly</a></li><li class="item-562"><a href="/joomla/paradise/index.php/features/search-site" >Search Site</a></li><li class="item-356"><a href="/joomla/paradise/index.php/features/typography" >Typography</a></li></ul></li><li class="item-465"><a href="/joomla/paradise/index.php/blog" >Blog</a></li><li class="item-464"><a href="/joomla/paradise/index.php/contact-us" >Contact Us</a></li>	</ul>

	</nav>
	</div>
</div>				<div class="sparky_cell mp_search sparkle2">
							<div class="moduletable">
						<div class="search">
	<form action="/joomla/paradise/index.php" method="post" class="form-inline">
		<label for="mod-search-searchword387" class="element-invisible">Search ...</label> <input name="searchword" id="mod-search-searchword387" maxlength="200"  class="inputbox search-query input-medium" type="search" placeholder="Search ..." /> <input type="image" alt="Submit" class="button" src="/joomla/paradise/templates/sparky_framework/images/searchButton.gif" onclick="this.form.searchword.focus();"/>		<input type="hidden" name="task" value="search" />
		<input type="hidden" name="option" value="com_search" />
		<input type="hidden" name="Itemid" value="195" />
	</form>
</div>
		</div>
	
				</div>
                        </div>
    </div>
    <div  class="sparky_row2 sparky_full carouselrow full">
        <div class="sparky_container">
        				<div class="sparky_cell mp_header1 sparkle12">
							<div class="moduletable">
						
<div class="hot_swipe_carousel_slides">
                        <div class="gallery-cell">
                        <img srcset="http://demo.hot-themes.com/joomla/paradise/images/carousel/slide1-2x.jpg 2x" src="http://demo.hot-themes.com/joomla/paradise/images/carousel/slide1.jpg" alt="slide 1" />
                                                <div class="contents">
                                                        <h2>For Your Leisure</h2>
                            <h3>The Place For Your Enjoyment</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eius adipisci, sed libero. Iste asperiores suscipit, consequatur
debitis animi impedit numquam facilis iusto porro labore dolorem, maxime magni incidunt. <a href="/joomla/paradise/index.php/about-us">Learn More</a></p>  
                        </div>
                                            </div>
                                <div class="gallery-cell">
                        <img  src="http://demo.hot-themes.com/joomla/paradise/images/carousel/slide2.jpg" alt="slide 2" />
                                                <div class="contents">
                                                        <h2>Sounds Of The Sea</h2>
                            <h3>Relaxing Beaches</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eius adipisci, sed libero. Iste asperiores suscipit, consequatur
debitis animi impedit numquam facilis iusto porro labore dolorem, maxime magni incidunt. <a href="/joomla/paradise/index.php/beaches-pools">Learn More</a></p>  
                        </div>
                                            </div>
                                <div class="gallery-cell">
                        <img  src="http://demo.hot-themes.com/joomla/paradise/images/carousel/slide3.jpg" alt="slide 3" />
                                                <div class="contents">
                                                        <h2>Delicious Food</h2>
                            <h3>A La Cart Restaurants</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eius adipisci, sed libero. Iste asperiores suscipit, consequatur
debitis animi impedit numquam facilis iusto porro labore dolorem, maxime magni incidunt. <a href="/joomla/paradise/index.php/delicious-food">Learn More</a></p>  
                        </div>
                                            </div>
                                <div class="gallery-cell">
                        <img  src="http://demo.hot-themes.com/joomla/paradise/images/carousel/slide4.jpg" alt="slide 4" />
                                                <div class="contents">
                                                        <h2>Passion In Each Bottle</h2>
                            <h3>Local Winery</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eius adipisci, sed libero. Iste asperiores suscipit, consequatur
debitis animi impedit numquam facilis iusto porro labore dolorem, maxime magni incidunt. <a href="/joomla/paradise/index.php/exotic-drinks">Learn More</a></p>  
                        </div>
                                            </div>
                                <div class="gallery-cell">
                        <img  src="http://demo.hot-themes.com/joomla/paradise/images/carousel/slide5.jpg" alt="slide 5" />
                                                <div class="contents">
                                                        <h2>For Active People</h2>
                            <h3>Variety Of Sports</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eius adipisci, sed libero. Iste asperiores suscipit, consequatur
debitis animi impedit numquam facilis iusto porro labore dolorem, maxime magni incidunt. <a href="/joomla/paradise/index.php/sport-activities">Learn More</a></p>  
                        </div>
                                            </div>
            </div>

<script>
    jQuery(document).ready(function(){
        jQuery('.hot_swipe_carousel_slides').flickity({
            // options
            cellAlign: 'left',
            contain: true,
            freeScroll: false,
            wrapAround: true,
            prevNextButtons: false,
            pageDots: true,
            autoPlay: 6000,
            imagesLoaded: true        });
        jQuery('.hot_swipe_carousel_slides .contents').css('opacity', 1);
    });
</script>		</div>
	
				</div>
                        </div>
    </div>
    <div  class="sparky_row3 sparky_full advertrow">
        <div class="sparky_container">
        <h2 class="row_heading">Summer You'll Never Forget</h2> 
			<h3 class="row_subheading">Resort Services</h3> 
							<div class="sparky_cell mp_advert1 sparkle3">
							<div class="moduletable">
						

<div class="custom"  >
	<div class="advert_image">
<a href="/joomla/paradise/index.php/sport-activities"><img src="/joomla/paradise/images/services/beach_volley.jpg" srcset="/joomla/paradise/images/services/beach_volley-@2x.jpg 2x" class="img-with-animation" data-delay="200" data-animation="grow-in" alt="beach volley" /></a>
</div>
<div class="advert_text">
<h3><span>Beach</span> Sports</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
</div>
<div class="clr"></div></div>
		</div>
			<div class="moduletable">
						

<div class="custom"  >
	<div class="advert_image">
<a href="/joomla/paradise/index.php/beaches-pools"><img src="/joomla/paradise/images/services/pool.jpg" srcset="/joomla/paradise/images/services/pool-@2x.jpg 2x" class="img-with-animation" data-delay="800" data-animation="grow-in"  alt="pool" /></a>
</div>
<div class="advert_text">
<h3><span>Fancy</span> Pools</h3>
<p>Facilis iusto porro labore dolorem, maxime magni incidunt.</p>
</div>
<div class="clr"></div></div>
		</div>
	
				</div>
                				<div class="sparky_cell mp_advert2 sparkle9">
							<div class="moduletable">
						

<div class="custom"  >
	<div class="advert_image">
<a href="/joomla/paradise/index.php/delicious-food"><img src="/joomla/paradise/images/services/food.jpg" srcset="/joomla/paradise/images/services/food-@2x.jpg 2x" class="img-with-animation" data-delay="400" data-animation="grow-in"  alt="food" /></a>
</div>
<div class="advert_text">
<h3><span>Nice</span> Foods</h3>
<p>Eius adipisci, sed libero. Iste asperiores suscipit, consequatur debitis animi impedit numquam facilis.</p>
</div>
<div class="clr"></div></div>
		</div>
			<div class="moduletable">
						

<div class="custom"  >
	<div class="advert_image">
<a href="/joomla/paradise/index.php/exotic-drinks"><img src="/joomla/paradise/images/services/cocktail.jpg" srcset="/joomla/paradise/images/services/cocktail-@2x.jpg 2x" class="img-with-animation" data-delay="600" data-animation="grow-in"  alt="cocktail" /></a>
</div>
<div class="advert_text">
<h3><span>Exotic</span> Drinks</h3>
<p>Debitis animi impedit numquam facilis iusto porro labore dolorem, maxime magni incidunt.</p>
</div>
<div class="clr"></div></div>
		</div>
	
				</div>
                        </div>
    </div>
    <div  class="sparky_row4 sparky_full countersrow">
        <div class="sparky_container">
        				<div class="sparky_cell mp_header2 sparkle12">
							<div class="moduletable">
						

<div class="counter_container">
      <div class="counter_field">
            <div class="counter_icon">
        <img src="/joomla/paradise/images/counters/fruit_salad.png" alt="" />
      </div>
            <div id="counter1" class="counter_number">12687</div>
      <div class="counter_text">Fruit Salads Served</div>
    </div>
        <div class="counter_field">
            <div class="counter_icon">
        <img src="/joomla/paradise/images/counters/pretzel.png" alt="" />
      </div>
            <div id="counter2" class="counter_number">8321</div>
      <div class="counter_text">Pretzels Oven Baked</div>
    </div>
        <div class="counter_field">
            <div class="counter_icon">
        <img src="/joomla/paradise/images/counters/cocktail.png" alt="" />
      </div>
            <div id="counter3" class="counter_number">17502</div>
      <div class="counter_text">Cocktails Prepared</div>
    </div>
        <div class="counter_field">
            <div class="counter_icon">
        <img src="/joomla/paradise/images/counters/piano.png" alt="" />
      </div>
            <div id="counter4" class="counter_number">769</div>
      <div class="counter_text">Live Music Shows</div>
    </div>
              </div>

<script>
  jQuery(function() {

      jQuery(".counter_container").appear(function() {
                              jQuery('#counter1').animateNumber({ number: 12687, easing: 'easeInQuad' },3000);
                                        jQuery('#counter2').animateNumber({ number: 8321, easing: 'easeInQuad' },4000);
                                        jQuery('#counter3').animateNumber({ number: 17502, easing: 'easeInQuad' },5000);
                                        jQuery('#counter4').animateNumber({ number: 769, easing: 'easeInQuad' },6000);
                                                                                                                                    });

  });
</script>
		</div>
	
				</div>
                        </div>
    </div>
    <div  class="sparky_row5 sparky_full contentrow">
        <div class="sparky_container">
        <h2 class="row_heading">Learn What We Have To Offer</h2> 
			<h3 class="row_subheading">Hotel Facilities</h3> 
			                <main class="sparky_cell content_sparky sparkle12">
                    <div id="system-message-container">
	</div>

                                        <div class="blog-featured" itemscope itemtype="https://schema.org/Blog">

	
		
		<div class="items-row cols-1 row-0 row-fluid">
					<div class="item column-1 span12"
				itemprop="blogPost" itemscope itemtype="https://schema.org/BlogPosting">
			


		<div class="pull-right item-image">
		<img
		class="img-with-animation" 			data-delay="200" data-animation="fade-in-from-right"
		 src="/joomla/paradise/images/blog/room.jpg" srcset="/joomla/paradise/images/blog/room-@2x.jpg 2x" alt="Room"
					/>
	</div>

	<h2 class="item-title" itemprop="name">
			<a href="/joomla/paradise/index.php/rooms-suites" itemprop="url">
			Rooms &amp; Suites		</a>
		</h2>






<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eius adipisci, sed libero. Iste asperiores suscipit, consequatur debitis animi impedit numquam facilis iusto porro labore dolorem, maxime magni incidunt. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat.</p>



	
<p class="readmore">
			<a class="btn" href="/joomla/paradise/index.php/rooms-suites" itemprop="url" aria-label="Read more:  Rooms &amp; Suites">
			<span class="icon-chevron-right" aria-hidden="true"></span> 
			Read more ...		</a>
	</p>



			</div>
			
			
		</div>
		
	
		
		<div class="items-row cols-1 row-1 row-fluid">
					<div class="item column-1 span12"
				itemprop="blogPost" itemscope itemtype="https://schema.org/BlogPosting">
			


		<div class="pull-right item-image">
		<img
		class="img-with-animation" 			data-delay="200" data-animation="fade-in-from-right"
		 src="/joomla/paradise/images/blog/restaurant.jpg" srcset="/joomla/paradise/images/blog/restaurant-@2x.jpg 2x" alt="Restaurant"
					/>
	</div>

	<h2 class="item-title" itemprop="name">
			<a href="/joomla/paradise/index.php/restaurant" itemprop="url">
			Restaurant A La Cart		</a>
		</h2>






<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eius adipisci, sed libero. Iste asperiores suscipit, consequatur debitis animi impedit numquam facilis iusto porro labore dolorem, maxime magni incidunt. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat.</p>



	
<p class="readmore">
			<a class="btn" href="/joomla/paradise/index.php/restaurant" itemprop="url" aria-label="Read more:  Restaurant A La Cart">
			<span class="icon-chevron-right" aria-hidden="true"></span> 
			Read more ...		</a>
	</p>



			</div>
			
			
		</div>
		
	


</div>

                                    </main>
                    </div>
    </div>
    <div  class="sparky_row6 sparky_full pricingrow">
        <div class="sparky_container">
        <h2 class="row_heading">Pricing Table</h2> 
							<div class="sparky_cell mp_user1 sparkle3">
							<div class="moduletable">
							<h3>Single</h3>
						

<div class="custom"  >
	<ul>
<li>Bed and breakfast included</li>
<li>Single room / 20 sq.m</li>
<li>One person max.</li>
<li>Garden view</li>
<li>Private bathroom with shower</li>
<li class="price">$49 / per night*</li>
</ul>
<a href="#" class="btn">Reserve</a></div>
		</div>
	
				</div>
                				<div class="sparky_cell mp_user2 sparkle3">
							<div class="moduletable">
							<h3>Double</h3>
						

<div class="custom"  >
	<ul>
<li>Half Board included</li>
<li>Double room / 25 sq.m</li>
<li>Two persons max.</li>
<li>Garden view</li>
<li>Private bathroom with jacuzzi</li>
<li class="price">$69 / per night*</li>
</ul>
<a href="#" class="btn">Reserve</a></div>
		</div>
	
				</div>
                				<div class="sparky_cell mp_user3 sparkle3">
							<div class="moduletable">
							<h3>Family</h3>
						

<div class="custom"  >
	<ul>
<li>All inclusive</li>
<li>Single room / 35 sq.m</li>
<li>Four persons max.</li>
<li>Sea view</li>
<li>Private bathroom with jacuzzi</li>
<li class="price">$99 / per night*</li>
</ul>
<a href="#" class="btn">Reserve</a></div>
		</div>
	
				</div>
                				<div class="sparky_cell mp_user4 sparkle3">
							<div class="moduletable">
							<h3>Apartment</h3>
						

<div class="custom"  >
	<ul>
<li>Ultra all inclusive</li>
<li>Living room / 2 bedrooms / 60 sq.m</li>
<li>Six persons max.</li>
<li>Sea view</li>
<li>Private bathroom with jacuzzi</li>
<li class="price">$149 / per night*</li>
</ul>
<a href="#" class="btn">Reserve</a></div>
		</div>
	
				</div>
                        </div>
    </div>
    <div  class="sparky_row7 sparky_full testimonialsrow">
        <div class="sparky_container">
        <h2 class="row_heading">Testimonials From Our Guests</h2> 
			<h3 class="row_subheading">Guest Book</h3> 
							<div class="sparky_cell mp_advert5 sparkle6">
							<div class="moduletable">
						

<div class="custom"  >
	<div><img src="/joomla/paradise/images/testimonials/helena.jpg" srcset="/joomla/paradise/images/testimonials/helena-@2x.jpg 2x" class="img-with-animation" data-delay="200" data-animation="grow-in"  alt="helena" /></div>
<h3><span>Helena</span> Ray</h3>
<p>Debitis animi impedit numquam facilis iusto porro labore dolorem, maxime magni incidunt.</p></div>
		</div>
	
				</div>
                				<div class="sparky_cell mp_advert6 sparkle6">
							<div class="moduletable">
						

<div class="custom"  >
	<div><img src="/joomla/paradise/images/testimonials/marcus.jpg" srcset="/joomla/paradise/images/testimonials/marcus-@2x.jpg 2x" class="img-with-animation" data-delay="400" data-animation="grow-in"  alt="marcus" /></div>
<h3><span>Mark</span> Smith</h3>
<p>Facilis iusto porro labore dolorem, maxime magni incidunt.</p></div>
		</div>
	
				</div>
                        </div>
    </div>
    <div  class="sparky_row8 sparky_full bottomrow">
        <div class="sparky_container">
        <div class="sparky_cell mp_bottommenu1 sparkle3">
	<div class="sparky_menu">
	<h3>Sport Activities</h3>
<nav class="container_bottommenu1">

	
	<ul class="menu standard mnu_bottommenu1">
<li class="item-513"><a href="/joomla/paradise/index.php/beach-volley" >Beach Volley</a></li><li class="item-514"><a href="/joomla/paradise/index.php/scuba-diving-school" >Scuba Diving School</a></li><li class="item-515"><a href="/joomla/paradise/index.php/swimming-deep-diving" >Swimming &amp; Deep Diving</a></li><li class="item-516"><a href="/joomla/paradise/index.php/tennis-courts-equippment" >Tennis Courts &amp; Equippment</a></li><li class="item-517"><a href="/joomla/paradise/index.php/billiard-snooker-tables" >Billiard &amp; Snooker Tables</a></li><li class="item-518"><a href="/joomla/paradise/index.php/darts-tournments" >Darts Tournments</a></li>	</ul>

	</nav>
	</div>
</div><div class="sparky_cell mp_bottommenu2 sparkle3">
	<div class="sparky_menu">
	<h3>Delicious Food</h3>
<nav class="container_bottommenu2">

	
	<ul class="menu copy_bottommenu1 standard mnu_bottommenu2">
<li class="item-519"><a href="/joomla/paradise/index.php/main-restaurant" >Main Restaurant</a></li><li class="item-520"><a href="/joomla/paradise/index.php/chinese-restaurant" >Chinese Restaurant</a></li><li class="item-521"><a href="/joomla/paradise/index.php/pizzeria-italian-food" >Pizzeria &amp; Italian Food</a></li><li class="item-522"><a href="/joomla/paradise/index.php/fast-food-drink-bars" >Fast Food &amp; Drink Bars</a></li><li class="item-523"><a href="/joomla/paradise/index.php/a-la-cart-restaurants" >A La Cart Restaurants</a></li>	</ul>

	</nav>
	</div>
</div><div class="sparky_cell mp_bottommenu3 sparkle3">
	<div class="sparky_menu">
	<h3>Exotic Cocktails</h3>
<nav class="container_bottommenu3">

	
	<ul class="menu copy_bottommenu1 standard mnu_bottommenu3">
<li class="item-524"><a href="/joomla/paradise/index.php/local-organic-winery" >Local Organic Winery</a></li><li class="item-525"><a href="/joomla/paradise/index.php/variety-of-beers" >Variety of Beers</a></li><li class="item-526"><a href="/joomla/paradise/index.php/99-exotic-coctails" >99 Exotic Coctails</a></li><li class="item-527"><a href="/joomla/paradise/index.php/pool-beach-service" >Pool &amp; Beach Service</a></li><li class="item-528"><a href="/joomla/paradise/index.php/night-bar" >Night Bar</a></li>	</ul>

	</nav>
	</div>
</div><div class="sparky_cell mp_bottommenu4 sparkle3">
	<div class="sparky_menu">
	<h3>Beaches & Pools</h3>
<nav class="container_bottommenu4">

	
	<ul class="menu copy_bottommenu1 standard mnu_bottommenu4">
<li class="item-529"><a href="/joomla/paradise/index.php/organized-beach" >Organized Beach</a></li><li class="item-530"><a href="/joomla/paradise/index.php/private-beaches" >Private Beaches</a></li><li class="item-531"><a href="/joomla/paradise/index.php/aqualandia-park" >&quot;Aqualandia&quot; Park</a></li><li class="item-532"><a href="/joomla/paradise/index.php/classic-pools" >Classic Pools</a></li><li class="item-533"><a href="/joomla/paradise/index.php/pools-for-children" >Pools For Children</a></li>	</ul>

	</nav>
	</div>
</div>        </div>
    </div>
    <div  class="sparky_row9 sparky_full footerrow">
        <div class="sparky_container">
        				<div class="sparky_cell mp_footer sparkle3">
							<div class="moduletable">
						

<div class="custom"  >
	<div class="sparky_logo"><a href="/joomla/paradise/index.php"><span>PA</span><span>RA</span><span>DI</span><span>SE</span></a></div></div>
		</div>
	
				</div>
                <div class="sparky_cell mp_copyright sparkle9">
    <div class="sparky_feature">
    	<p class="copyright">Copyright &copy; 2018 Your Company. <a href="http://www.hotjoomlatemplates.com">Joomla templates</a> powered by Sparky.</p>
    </div>
</div>        </div>
    </div>
</div>
<script type="text/javascript" src="/joomla/paradise/templates/sparky_framework/js/sparky-footer-id83-180526075302.js"></script>
</body>
</html>